% temp scripts that plots data

figure, hold on
c = parula(length(data));
s = NaN(length(data),1);
for i = 2:length(data)
    for j = 1:width(data(i).PID)
        [y,x] = hist(data(i).PID(j,30000:end),50);
        plot(x,y)
        % fit gaussians to each
        cf = fit(x(:),y(:),'gauss1');
        s(i) = cf.b1;
    end
end


